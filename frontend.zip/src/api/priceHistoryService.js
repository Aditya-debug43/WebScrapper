import { mockDelay } from "./client";
import { getListing } from "../data/listings";
import { getOffersForListing } from "../data/offers";
import { getSeller } from "../data/sellers";
import { getPriceHistoryForOffer } from "../data/priceObservations";
import { getProduct } from "../data/products";
import { marketplaces } from "../data/marketplaces";

/** GET /api/listings/:id/price-history — every offer's observation series on this listing. */
export async function getPriceHistoryForListing(listingId) {
  await mockDelay();
  const listing = getListing(listingId);
  if (!listing) return null;
  const product = getProduct(listing.productId);
  const marketplace = marketplaces.find((m) => m.id === listing.marketplaceId);
  const series = getOffersForListing(listingId).map((offer) => ({
    offer,
    seller: getSeller(offer.sellerId),
    observations: getPriceHistoryForOffer(offer.id),
  }));
  return { listing, product, marketplace, series };
}
